/**
 * Form field label text. See the LABEL element definition in HTML 4.01.
 */
var HTMLLabelElement = {
}
/**
 * A single character access key to give access to the form control. See the accesskey attribute definition in HTML 4.01.
 * @syntax hTMLLabelElement.accessKey
 * @returns {String} 
 */
HTMLLabelElement.prototype.accessKey = new String();

/**
 * Returns the FORM element containing this control. Returns null if this control is not within the context of a form.
 * @syntax hTMLLabelElement.form
 * @returns {HTMLFormElement} 
 */
HTMLLabelElement.prototype.form = new HTMLFormElement();

/**
 * This attribute links this label with another form control by id attribute. See the for attribute definition in HTML 4.01.
 * @syntax hTMLLabelElement.htmlFor
 * @returns {String} 
 */
HTMLLabelElement.prototype.htmlFor = new String();

/**
 * Represents the HTMLLabelElement prototype object.
 * @syntax HTMLLabelElement.prototype
 * @static
 */
HTMLLabelElement.prototype;

