/**
 * The DocumentView interface is implemented by Document objects in DOM implementations supporting DOM Views. It provides an attribute to retrieve the default view of a document.
 */
var DocumentView = {
}
/**
 * The default AbstractView for this Document, or null if none available.
 * @syntax documentView.defaultView
 * @returns {AbstractView} 
 */
DocumentView.prototype.defaultView = new AbstractView();

/**
 * Represents the DocumentView prototype object.
 * @syntax DocumentView.prototype
 * @static
 */
DocumentView.prototype;

