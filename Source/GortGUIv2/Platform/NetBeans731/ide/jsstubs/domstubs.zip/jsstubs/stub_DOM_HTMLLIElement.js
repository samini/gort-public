/**
 * List item. See the LI element definition in HTML 4.01.
 */
var HTMLLIElement = {
}
/**
 * Reset sequence number when used in OL. See the value attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLLIElement.value
 * @returns {Number} 
 */
HTMLLIElement.prototype.value = new Number();

/**
 * List item bullet style. See the type attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLLIElement.type
 * @returns {String} 
 */
HTMLLIElement.prototype.type = new String();

/**
 * Represents the HTMLLIElement prototype object.
 * @syntax HTMLLIElement.prototype
 * @static
 */
HTMLLIElement.prototype;

