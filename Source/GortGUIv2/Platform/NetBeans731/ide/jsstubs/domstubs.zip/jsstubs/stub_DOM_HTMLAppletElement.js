/**
 * An embedded Java applet. See the APPLET element definition in HTML 4.01. This element is deprecated in HTML 4.01.
 */
var HTMLAppletElement = {
}
/**
 * Optional base URI [IETF RFC 2396] for applet. See the codebase attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.codeBase
 * @returns {String} 
 */
HTMLAppletElement.prototype.codeBase = new String();

/**
 * Override height. See the height attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.height
 * @returns {String} 
 */
HTMLAppletElement.prototype.height = new String();

/**
 * Horizontal space, in pixels, to the left and right of this image, applet, or object. See the hspace attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.hspace
 * @returns {Number} 
 */
HTMLAppletElement.prototype.hspace = new Number();

/**
 * Alternate text for user agents not rendering the normal content of this element. See the alt attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.alt
 * @returns {String} 
 */
HTMLAppletElement.prototype.alt = new String();

/**
 * Aligns this object (vertically or horizontally) with respect to its surrounding text. See the align attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.align
 * @returns {String} 
 */
HTMLAppletElement.prototype.align = new String();

/**
 * The name of the applet. See the name attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.name
 * @returns {String} 
 */
HTMLAppletElement.prototype.name = new String();

/**
 * Override width. See the width attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.width
 * @returns {String} 
 */
HTMLAppletElement.prototype.width = new String();

/**
 * Comma-separated archive list. See the archive attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.archive
 * @returns {String} 
 */
HTMLAppletElement.prototype.archive = new String();

/**
 * Applet class file. See the code attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.code
 * @returns {String} 
 */
HTMLAppletElement.prototype.code = new String();

/**
 * The value of the "object" attribute. See the object attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.object
 * @returns {String} 
 */
HTMLAppletElement.prototype.object = new String();

/**
 * Vertical space, in pixels, above and below this image, applet, or object. See the vspace attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLAppletElement.vspace
 * @returns {Number} 
 */
HTMLAppletElement.prototype.vspace = new Number();

/**
 * Represents the HTMLAppletElement prototype object.
 * @syntax HTMLAppletElement.prototype
 * @static
 */
HTMLAppletElement.prototype;

