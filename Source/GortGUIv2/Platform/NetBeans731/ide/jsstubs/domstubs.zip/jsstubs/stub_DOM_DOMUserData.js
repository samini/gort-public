/**
 * A DOMUserData represents a reference to application data.
 */
var DOMUserData = {
}
/**
 * Represents the DOMUserData prototype object.
 * @syntax DOMUserData.prototype
 * @static
 */
DOMUserData.prototype;

