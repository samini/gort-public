/**
 * Unordered list. See the UL element definition in HTML 4.01.
 */
var HTMLUListElement = {
}
/**
 * Reduce spacing between list items. See the compact attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLUListElement.compact
 * @returns {boolean} 
 */
HTMLUListElement.prototype.compact = new boolean();

/**
 * Bullet style. See the type attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLUListElement.type
 * @returns {String} 
 */
HTMLUListElement.prototype.type = new String();

/**
 * Represents the HTMLUListElement prototype object.
 * @syntax HTMLUListElement.prototype
 * @static
 */
HTMLUListElement.prototype;

