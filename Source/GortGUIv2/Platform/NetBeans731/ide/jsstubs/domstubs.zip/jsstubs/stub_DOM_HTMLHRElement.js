/**
 * Create a horizontal rule. See the HR element definition in HTML 4.01.
 */
var HTMLHRElement = {
}
/**
 * Indicates to the user agent that there should be no shading in the rendering of this element. See the noshade attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLHRElement.noShade
 * @returns {boolean} 
 */
HTMLHRElement.prototype.noShade = new boolean();

/**
 * Align the rule on the page. See the align attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLHRElement.align
 * @returns {String} 
 */
HTMLHRElement.prototype.align = new String();

/**
 * The width of the rule. See the width attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLHRElement.width
 * @returns {String} 
 */
HTMLHRElement.prototype.width = new String();

/**
 * The height of the rule. See the size attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLHRElement.size
 * @returns {String} 
 */
HTMLHRElement.prototype.size = new String();

/**
 * Represents the HTMLHRElement prototype object.
 * @syntax HTMLHRElement.prototype
 * @static
 */
HTMLHRElement.prototype;

