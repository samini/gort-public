/**
 * Create a frame. See the FRAME element definition in HTML 4.01.
 */
var HTMLFrameElement = {
}
/**
 * Specify whether or not the frame should have scrollbars. See the scrolling attribute definition in HTML 4.01.
 * @syntax hTMLFrameElement.scrolling
 * @returns {String} 
 */
HTMLFrameElement.prototype.scrolling = new String();

/**
 * The frame name (object of the target attribute). See the name attribute definition in HTML 4.01.
 * @syntax hTMLFrameElement.name
 * @returns {String} 
 */
HTMLFrameElement.prototype.name = new String();

/**
 * URI [IETF RFC 2396] designating a long description of this image or frame. See the longdesc attribute definition in HTML 4.01.
 * @syntax hTMLFrameElement.longDesc
 * @returns {String} 
 */
HTMLFrameElement.prototype.longDesc = new String();

/**
 * Frame margin height, in pixels. See the marginheight attribute definition in HTML 4.01.
 * @syntax hTMLFrameElement.marginHeight
 * @returns {String} 
 */
HTMLFrameElement.prototype.marginHeight = new String();

/**
 * When true, forbid user from resizing frame. See the noresize attribute definition in HTML 4.01.
 * @syntax hTMLFrameElement.noResize
 * @returns {boolean} 
 */
HTMLFrameElement.prototype.noResize = new boolean();

/**
 * Frame margin width, in pixels. See the marginwidth attribute definition in HTML 4.01.
 * @syntax hTMLFrameElement.marginWidth
 * @returns {String} 
 */
HTMLFrameElement.prototype.marginWidth = new String();

/**
 * Request frame borders. See the frameborder attribute definition in HTML 4.01.
 * @syntax hTMLFrameElement.frameBorder
 * @returns {String} 
 */
HTMLFrameElement.prototype.frameBorder = new String();

/**
 * A URI [IETF RFC 2396] designating the initial frame contents. See the src attribute definition in HTML 4.01.
 * @syntax hTMLFrameElement.src
 * @returns {String} 
 */
HTMLFrameElement.prototype.src = new String();

/**
 * The document this frame contains, if there is any and it is available, or null otherwise.
 * @syntax hTMLFrameElement.contentDocument
 * @returns {Document} 
 */
HTMLFrameElement.prototype.contentDocument = new Document();

/**
 * Represents the HTMLFrameElement prototype object.
 * @syntax HTMLFrameElement.prototype
 * @static
 */
HTMLFrameElement.prototype;

