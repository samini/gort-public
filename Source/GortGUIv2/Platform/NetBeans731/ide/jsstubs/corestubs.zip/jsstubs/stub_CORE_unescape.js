/**
 * @syntax unescape(string)
 * @param {String} string 
 * @returns {String} 
 */
function unescape(string) {};
