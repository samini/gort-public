/**
 * @syntax eval(string)
 * @param {String} string
 * @returns {Object}
 */
function eval(string) {};
