/**
 * @syntax [element0, element1, ..., elementN] new Array(element0, element1, ..., elementN) new Array(arrayLength)
 * @returns {Array}
 */
function Array(element0,  element1) {
}
/**
 * @syntax splice(start,deleteCount[,item1[,item2[,...]]])
 * @param {Number} start
 * @param {Number} deleteCount
 * @returns {Array}
 */
Array.prototype.splice = function(start, deleteCount) {};

/**
 * @syntax reverse()
 * @returns {Array}
 */
Array.prototype.reverse = function() {};

/**
 * @syntax sort(comparefn)
 * @param {Array} comparefn
 * @returns {Array}
 */
Array.prototype.sort = function(comparefn) {};

/**
 * @syntax forEach(callbackfn[,thisArg])
 * @param {Function} callbackfn
 * @returns {undefined}
 */
Array.prototype.forEach = function(callbackfn) {};

/**
 * @syntax reduceRight(callbackfn[,initialValue])
 * @param {Function} callbackfn
 * @returns {Object}
 */
Array.prototype.reduceRight = function(callbackfn) {};

/**
 * @syntax lastIndexOf(searchElement[,fromIndex])
 * @param {Object} searchElement
 * @returns {Number}
 */
Array.prototype.lastIndexOf = function(searchElement) {};

/**
 * @syntax pop()
 * @returns {Object}
 */
Array.prototype.pop = function() {};

/**
 * @syntax join(separator)
 * @param {String} separator
 * @returns {String}
 */
Array.prototype.join = function(separator) {};

/**
 * @syntax indexOf(searchElement[,fromIndex])
 * @param {Array} searchElement
 * @returns {Number}
 */
Array.prototype.indexOf = function(searchElement) {};

/**
 * @syntax every(callbackfn[,thisArg])
 * @param {Function} callbackfn
 * @returns {Boolean}
 */
Array.prototype.every = function(callbackfn) {};

/**
 * @syntax concat([item1[,item2[,...]]])
 * @param {Array} 
 * @returns {Array}
 */
Array.prototype.concat = function() {};

/**
 * @syntax reduce(callbackfn[,initialValue])
 * @param {Function} callbackfn
 * @returns {Object}
 */
Array.prototype.reduce = function(callbackfn) {};

/**
 * @syntax push([item1[,item2[,...]]])
 * @param {Array} 
 * @returns {Number}
 */
Array.prototype.push = function() {};

/**
 * @syntax length
 * @returns {Number}
 */
Array.prototype.length = new Number();

/**
 * @syntax map(callbackfn[,thisArg])
 * @param {Function} callbackfn
 * @returns {Array}
 */
Array.prototype.map = function(callbackfn) {};

/**
 * @syntax toString()
 * @returns {String}
 */
Array.prototype.toString = function() {};

/**
 * @syntax slice(start,end)
 * @param {Number} start
 * @param {Number} end
 * @returns {Array}
 */
Array.prototype.slice = function(start, end) {};

/**
 * @syntax unshift([item1[,item2[,...]]])
 * @param {Array} 
 * @returns {Number}
 */
Array.prototype.unshift = function() {};

/**
 * @syntax some(callbackfn[,thisArg])
 * @param {Function} callbackfn
 * @returns {Boolean}
 */
Array.prototype.some = function(callbackfn) {};

/**
 * @syntax isArray(arg)
 * @param {Object} arg
 * @returns {Boolean}
 * @static
 */
Array.isArray = function(arg) {};

/**
 * @syntax filter(callbackfn[,thisArg])
 * @param {Function} callbackfn
 * @returns {Array}
 */
Array.prototype.filter = function(callbackfn) {};

/**
 * @syntax shift()
 * @returns {Object}
 */
Array.prototype.shift = function() {};

/**
 * @syntax constructor
 * @returns {Function}
 */
Array.prototype.constructor = new Function();

/**
 * @syntax prototype
 * @returns {Object}
 * @static
 */
Array.prototype;

