/**
 * @syntax new Number(value)
 * @param {Object} value
 * @returns {Number}
 */
function Number(value) {
}
/**
 * @syntax toLocaleString()
 * @returns {String}
 */
Number.prototype.toLocaleString = function() {};

/**
 * @syntax NaN
 * @returns {Number}
 * @static
 */
Number.NaN = new Number();

/**
 * @syntax toPrecision(precision)
 * @param {Number} precision
 * @returns {Number}
 */
Number.prototype.toPrecision = function(precision) {};

/**
 * @syntax NEGATIVE_INFINITY
 * @returns {String}
 * @static
 */
Number.NEGATIVE_INFINITY = new String();

/**
 * @syntax toFixed(fractionDigits)
 * @param {Number} fractionDigits
 * @returns {Number}
 */
Number.prototype.toFixed = function(fractionDigits) {};

/**
 * @syntax MAX_VALUE
 * @returns {Number}
 * @static
 */
Number.MAX_VALUE = new Number();

/**
 * @syntax toString([radix])
 * @param {Number} 
 * @returns {String}
 */
Number.prototype.toString = function() {};

/**
 * @syntax valueOf()
 * @returns {Number}
 */
Number.prototype.valueOf = function() {};

/**
 * @syntax toExponential(fractionDigits)
 * @param {Number} fractionDigits
 * @returns {Number}
 */
Number.prototype.toExponential = function(fractionDigits) {};

/**
 * @syntax MIN_VALUE
 * @returns {Number}
 * @static
 */
Number.MIN_VALUE = new Number();

/**
 * @syntax POSITIVE_INFINITY
 * @returns {String}
 * @static
 */
Number.POSITIVE_INFINITY = new String();

/**
 * @syntax constructor
 * @returns {Function}
 */
Number.prototype.constructor = new Function();

/**
 * @syntax prototype
 * @returns {Object}
 * @static
 */
Number.prototype;

