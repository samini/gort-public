/**
 */
var Navigator = {
}
/**
 * @syntax window.navigator.registerContentHandler(mimeType, uri, title);
 * @param {String} mimeType
 * @param {String} uri
 * @param {String} title
 * @returns {undefined}
 * @static
 */
Navigator.registerContentHandler = function(mimeType,  uri,  title) {};

/**
 * @returns {Boolean}
 * @static
 */
Navigator.cookieEnabled = new Boolean();

/**
 * @returns {String}
 * @static
 */
Navigator.platform = new String();

/**
 * @returns {String}
 * @static
 */
Navigator.buildID = new String();

/**
 * @returns {String}
 * @static
 */
Navigator.userAgent = new String();

/**
 * @returns {String}
 * @static
 */
Navigator.oscpu = new String();

/**
 * @returns {Array}
 * @static
 */
Navigator.plugins = new Array();

/**
 * @returns {String}
 * @static
 */
Navigator.vendor = new String();

/**
 * @syntax window.navigator.registerProtocolHandler(protocol, uri, title);
 * @param {String} protocol
 * @param {String} uri
 * @param {String} title
 * @returns {undefined}
 * @static
 */
Navigator.registerProtocolHandler = function(protocol,  uri,  title) {};

/**
 * @returns {String}
 * @static
 */
Navigator.mimeTypes = new String();

/**
 * @syntax result = window.navigator.javaEnabled();
 * @returns {Boolean}
 * @static
 */
Navigator.javaEnabled = function() {};

/**
 * @returns {String}
 * @static
 */
Navigator.appCodeName = new String();

/**
 * @returns {Boolean}
 * @static
 */
Navigator.onLine = new Boolean();

/**
 * @returns {String}
 * @static
 */
Navigator.vendorSub = new String();

/**
 * @returns {String}
 * @static
 */
Navigator.appName = new String();

/**
 * @returns {String}
 * @static
 */
Navigator.product = new String();

/**
 * @returns {String}
 * @static
 */
Navigator.doNotTrack = new String();

/**
 * @returns {String}
 * @static
 */
Navigator.appVersion = new String();

/**
 * @returns {String}
 * @static
 */
Navigator.productSub = new String();

/**
 * @returns {String}
 * @static
 */
Navigator.language = new String();

/**
 * Represents the Navigator prototype object.
 * @syntax Navigator.prototype
 * @static
 */
Navigator.prototype;

