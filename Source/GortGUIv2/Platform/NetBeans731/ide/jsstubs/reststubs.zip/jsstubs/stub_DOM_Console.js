/**
 */
var Console = {
}
/**
 * @syntax console.warn(obj1 [, obj2, ..., objN);<br>console.warn(msg [, subst1, ..., substN);
 * @param {Object} obj1
 * @returns {undefined}
 * @static
 */
Console.warn = function(obj1 ) {};

/**
 * @syntax console.time(timerName);
 * @param {String} timerName
 * @returns {undefined}
 * @static
 */
Console.time = function(timerName) {};

/**
 * @syntax console.timeEnd(timerName);
 * @param {String} timerName
 * @returns {undefined}
 * @static
 */
Console.timeEnd = function(timerName) {};

/**
 * @syntax console.error(obj1 [, obj2, ..., objN);<br>console.error(msg [, subst1, ..., substN);
 * @param {Object} obj1
 * @returns {undefined}
 * @static
 */
Console.error = function(obj1 ) {};

/**
 * @syntax console.dir(object);
 * @param {Object} object
 * @returns {undefined}
 * @static
 */
Console.dir = function(object) {};

/**
 * @syntax console.trace()
 * @returns {undefined}
 * @static
 */
Console.trace = function() {};

/**
 * @syntax console.groupCollapsed()
 * @returns {undefined}
 * @static
 */
Console.groupCollapsed = function() {};

/**
 * @syntax console.group()
 * @returns {undefined}
 * @static
 */
Console.group = function() {};

/**
 * @syntax console.log(obj1 [, obj2, ..., objN);<br>console.log(msg [, subst1, ..., substN);
 * @param {Object} obj1
 * @returns {undefined}
 * @static
 */
Console.log = function(obj1 ) {};

/**
 * @syntax console.info(obj1 [, obj2, ..., objN);<br>console.info(msg [, subst1, ..., substN);
 * @param {Object} obj1
 * @returns {undefined}
 * @static
 */
Console.info = function(obj1 ) {};

/**
 * @syntax console.groupEnd()
 * @returns {undefined}
 * @static
 */
Console.groupEnd = function() {};

/**
 * Represents the Console prototype object.
 * @syntax Console.prototype
 * @static
 */
Console.prototype;

