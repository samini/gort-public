#ifndef _BZ2_H                                                                                                                                                           
#define _BZ2_H

#include <stdio.h>
#include <stdlib.h>

int bz2Compress(int, const unsigned char *, size_t, unsigned char *, size_t *);

#endif
