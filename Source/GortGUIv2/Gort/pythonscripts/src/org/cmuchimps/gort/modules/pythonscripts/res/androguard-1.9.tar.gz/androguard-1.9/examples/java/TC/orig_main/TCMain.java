public class TCMain {
    public TCMain() {
    }
            
    public static void main(String args[]) {
      TCMod1 tm1 = new TCMod1();
      tm1.T1();
    }
    
}
