#!/bin/sh

javac -cp ../orig: Demo1Main.java

exit 0
