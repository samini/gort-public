package com.googlecode.gtalksms.contacts;

public class ContactAddress {
    public Long id;
    public String label;
    public String address;
}
